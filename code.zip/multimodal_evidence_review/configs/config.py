"""
Configuration for Multi-Modal Evidence Review Pipeline
"""
import os
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Config:
    # ── Anthropic API ─────────────────────────────────────────────────────────
    anthropic_api_key: str = field(
        default_factory=lambda: os.environ.get("ANTHROPIC_API_KEY", "")
    )
    model: str = "claude-opus-4-6"          # Best vision + reasoning model
    max_tokens: int = 1024
    temperature: float = 0.0                # Deterministic for consistency

    # ── Paths ─────────────────────────────────────────────────────────────────
    data_dir: str = "data"
    images_dir: str = "images"
    output_dir: str = "output"
    cache_dir: str = "cache"
    logs_dir: str = "logs"
    evaluation_dir: str = "evaluation"

    claims_file: str = "data/claims.csv"
    sample_claims_file: str = "data/sample_claims.csv"
    user_history_file: str = "data/user_history.csv"
    evidence_requirements_file: str = "data/evidence_requirements.csv"
    output_file: str = "output/output.csv"

    # ── Processing ────────────────────────────────────────────────────────────
    batch_size: int = 5                     # Claims per batch
    max_retries: int = 3
    retry_delay_seconds: float = 2.0
    max_images_per_claim: int = 4           # Cap to control cost
    image_max_size_bytes: int = 5_242_880   # 5 MB per image

    # ── Caching ───────────────────────────────────────────────────────────────
    enable_cache: bool = True
    cache_ttl_hours: int = 24

    # ── Risk thresholds ───────────────────────────────────────────────────────
    high_risk_score_threshold: int = 70
    medium_risk_score_threshold: int = 40
    fraud_flag_escalation_threshold: int = 2

    # ── Evaluation ────────────────────────────────────────────────────────────
    evaluation_output_file: str = "evaluation/evaluation_report.md"


# Default singleton config
DEFAULT_CONFIG = Config()
