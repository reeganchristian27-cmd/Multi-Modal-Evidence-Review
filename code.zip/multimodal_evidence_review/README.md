# Multi-Modal Evidence Review Pipeline

A production-ready AI pipeline for automated insurance claim adjudication using multimodal analysis: claim conversation text, photographic evidence, user risk history, and evidence requirement rules.

---

## Architecture

```
multimodal_evidence_review/
├── main.py                     # CLI entry point
├── requirements.txt
├── README.md
├── .env.example                 # API key template
│
├── configs/
│   ├── __init__.py
│   └── config.py                # Configuration dataclass
│
├── src/
│   ├── __init__.py
│   ├── logger.py                # Structured logging (console + file)
│   ├── cache.py                 # Disk-based response cache with TTL
│   ├── data_loader.py           # CSV loading, image encoding, context builders
│   ├── api_client.py            # Anthropic SDK wrapper with retry + JSON extraction
│   ├── pipeline.py              # Core analysis pipeline + batch processing
│   └── evaluator.py             # Evaluation framework + report generation
│
├── prompts/
│   ├── __init__.py
│   └── templates.py             # System + user prompt templates
│
├── data/
│   ├── claims.csv               # Production claims to process
│   ├── sample_claims.csv        # Labeled claims for evaluation
│   ├── user_history.csv         # User risk profiles
│   └── evidence_requirements.csv  # Evidence rules by issue type
│
├── images/                      # Claim images (referenced by claims.csv paths)
├── output/
│   └── output.csv               # Generated predictions
├── evaluation/
│   └── evaluation_report.md     # Auto-generated evaluation report
├── cache/                       # API response cache files (created at runtime)
└── logs/                        # Pipeline log files (created at runtime)
```

---

## Setup

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Set your API key

```bash
export ANTHROPIC_API_KEY=sk-ant-your-key-here
```

Or create a `.env` file:

```
ANTHROPIC_API_KEY=sk-ant-your-key-here
```

### 3. Prepare your data

Place your CSV files in `data/` and images in `images/`. Image paths in claims.csv should be semicolon-separated (e.g., `images/photo1.jpg;images/photo2.jpg`).

---

## Usage

### Run full pipeline on production claims

```bash
python main.py
```

### Run evaluation first, then production

```bash
python main.py --evaluate
```

### Evaluation only (no production run)

```bash
python main.py --evaluate --only-eval
```

### Clear cache and rerun

```bash
python main.py --clear-cache
```

### Custom paths

```bash
python main.py \
  --claims path/to/claims.csv \
  --user-history path/to/user_history.csv \
  --evidence-requirements path/to/evidence_requirements.csv \
  --output path/to/output.csv
```

---

## Input CSV Schemas

### claims.csv

| Column | Type | Description |
|--------|------|-------------|
| claim_id | string | Unique claim identifier |
| user_id | string | User identifier (optional, for risk lookup) |
| conversation | string | Full chat transcript between user and agent |
| image_paths | string | Semicolon-separated image file paths |

### sample_claims.csv (labeled, for evaluation)

Same as claims.csv plus:

| Column | Type | Description |
|--------|------|-------------|
| claim_status | string | Ground truth: `supported`, `contradicted`, `not_enough_information` |
| issue_type | string | Ground truth issue type |
| object_part | string | Ground truth damaged part |

### user_history.csv

| Column | Type | Description |
|--------|------|-------------|
| user_id | string | User identifier |
| total_claims | int | Lifetime claim count |
| approved_claims | int | Count of approved claims |
| rejected_claims | int | Count of rejected claims |
| fraud_flags | int | Number of fraud flags on account |
| risk_score | int | 0–100 risk score |
| risk_level | string | `low`, `medium`, `high` |

### evidence_requirements.csv

| Column | Type | Description |
|--------|------|-------------|
| issue_type | string | Damage type identifier |
| required_evidence | string | What evidence is needed |
| min_images | int | Minimum images required |
| image_quality_requirements | string | Quality criteria |
| accepted_object_parts | string | Semicolon-separated accepted parts |
| description | string | Human-readable rule description |

---

## Output CSV Schema (output.csv)

| Column | Description |
|--------|-------------|
| claim_id | Claim identifier |
| user_id | User identifier |
| issue_type | Detected damage type |
| object_part | Detected damaged part |
| claim_status | `supported` / `contradicted` / `not_enough_information` |
| confidence_score | 0.0–1.0 model confidence |
| image_quality | `clear` / `blurry` / `no_image` / `insufficient_detail` / `adequate` |
| evidence_sufficient | Boolean |
| damage_visible_in_image | Boolean or null |
| damage_consistent_with_claim | Boolean or null |
| risk_flags | Semicolon-separated flags |
| reasoning | 1–2 sentence explanation |
| recommended_action | `approve` / `reject` / `escalate_for_review` / `request_more_evidence` |
| n_images_submitted | Count of images submitted |
| user_risk_level | `low` / `medium` / `high` |
| user_risk_score | 0–100 |
| error | Error message if processing failed |

---

## Pipeline Logic

### Claim Status Rules

- **`supported`**: Images clearly show the claimed damage AND the damage type matches the conversation.
- **`contradicted`**: Images actively disprove the claim (damage type wrong, damage absent when clearly visible).
- **`not_enough_information`**: No images, blurry images, internal damage not visible from exterior, or insufficient detail.

### Image Primacy

Images are the **primary source of truth**. User history informs scrutiny level but never overrides visual evidence.

### Risk Escalation

Users with `risk_score ≥ 70` AND `fraud_flags ≥ 2` have supported claims automatically escalated to `escalate_for_review` rather than `approve`.

### Caching

API responses are cached by SHA-256 hash of the request payload with a 24-hour TTL. This prevents redundant API calls on reruns and reduces cost significantly.

### Retry Logic

On API rate limits or transient errors, the pipeline retries up to 3 times with exponential backoff (2s → 4s → 8s).

---

## Evaluation

The evaluation framework measures:

- **Accuracy**: Fraction of exact label matches
- **Per-class Precision / Recall / F1**: For each of the 3 status labels
- **Macro F1**: Unweighted mean F1 across classes
- **Confusion matrix**: Full breakdown of prediction vs ground truth

Results are written to `evaluation/evaluation_report.md`.

---

## Cost Optimization

- **Response caching** (24h TTL) eliminates duplicate API calls
- **Image cap** (max 4 images per claim, configurable) controls vision token usage
- **Image size limit** (5 MB per image) prevents oversized uploads
- **Heuristic pre-detection** of issue type selects relevant evidence requirements before the API call, reducing prompt length
- **`claude-opus-4-6`** provides best vision accuracy; swap to `claude-haiku-4-5-20251001` for 10× cost reduction with minor accuracy tradeoff

---

## Configuration

All settings are in `configs/config.py`. Key parameters:

| Parameter | Default | Description |
|-----------|---------|-------------|
| model | claude-opus-4-6 | Anthropic model |
| max_retries | 3 | API retry attempts |
| batch_size | 5 | Claims per log batch |
| max_images_per_claim | 4 | Image cap per claim |
| enable_cache | True | Response caching |
| cache_ttl_hours | 24 | Cache expiry |
| high_risk_score_threshold | 70 | Risk escalation threshold |
| fraud_flag_escalation_threshold | 2 | Fraud flag escalation trigger |
