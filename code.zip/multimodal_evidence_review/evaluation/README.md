Evaluation reports are generated here by running:

    python main.py --evaluate --only-eval
