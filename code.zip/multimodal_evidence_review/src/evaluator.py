"""
Evaluation framework for the Evidence Review pipeline.
Computes accuracy, per-class metrics, and generates a markdown report.
"""
import json
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import pandas as pd

from src.logger import logger
from src.pipeline import ClaimResult, EvidenceReviewPipeline


# ─── Metric helpers ───────────────────────────────────────────────────────────

def compute_metrics(
    predictions: List[str],
    ground_truth: List[str],
    labels: List[str] = ("supported", "contradicted", "not_enough_information"),
) -> Dict:
    """Compute overall accuracy and per-class precision/recall/F1."""
    assert len(predictions) == len(ground_truth), "Length mismatch"

    n = len(predictions)
    correct = sum(p == g for p, g in zip(predictions, ground_truth))
    accuracy = correct / n if n > 0 else 0.0

    # Per-class counts
    tp = defaultdict(int)
    fp = defaultdict(int)
    fn = defaultdict(int)

    for pred, true in zip(predictions, ground_truth):
        for label in labels:
            if pred == label and true == label:
                tp[label] += 1
            elif pred == label and true != label:
                fp[label] += 1
            elif pred != label and true == label:
                fn[label] += 1

    per_class = {}
    for label in labels:
        precision = tp[label] / (tp[label] + fp[label]) if (tp[label] + fp[label]) > 0 else 0.0
        recall = tp[label] / (tp[label] + fn[label]) if (tp[label] + fn[label]) > 0 else 0.0
        f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) > 0 else 0.0
        per_class[label] = {
            "precision": round(precision, 4),
            "recall": round(recall, 4),
            "f1": round(f1, 4),
            "support": tp[label] + fn[label],
        }

    # Macro-averaged F1
    macro_f1 = sum(per_class[l]["f1"] for l in labels) / len(labels)

    return {
        "accuracy": round(accuracy, 4),
        "macro_f1": round(macro_f1, 4),
        "per_class": per_class,
        "n_samples": n,
        "n_correct": correct,
    }


def compute_confusion_matrix(
    predictions: List[str],
    ground_truth: List[str],
    labels: List[str] = ("supported", "contradicted", "not_enough_information"),
) -> Dict[str, Dict[str, int]]:
    """Return confusion matrix as nested dict: cm[true][pred] = count."""
    cm: Dict[str, Dict[str, int]] = {l: {l2: 0 for l2 in labels} for l in labels}
    for pred, true in zip(predictions, ground_truth):
        if true in cm and pred in cm[true]:
            cm[true][pred] += 1
    return cm


# ─── Evaluator class ─────────────────────────────────────────────────────────

class PipelineEvaluator:

    def __init__(self, pipeline: EvidenceReviewPipeline):
        self.pipeline = pipeline

    def evaluate(
        self,
        sample_claims_df: pd.DataFrame,
        output_report_path: str = "evaluation/evaluation_report.md",
    ) -> Dict:
        """
        Run the pipeline on labeled sample claims, compare to ground truth,
        compute metrics, and write a markdown report.
        """
        logger.info(f"Starting evaluation on {len(sample_claims_df)} sample claims")
        Path(output_report_path).parent.mkdir(parents=True, exist_ok=True)

        # Run pipeline
        results = self.pipeline.process_batch(sample_claims_df)

        # Build comparison
        ground_truth_map = dict(
            zip(
                sample_claims_df["claim_id"].astype(str),
                sample_claims_df["claim_status"].str.strip().str.lower(),
            )
        )
        predictions = []
        ground_truths = []
        rows = []

        for result in results:
            gt = ground_truth_map.get(str(result.claim_id), "unknown")
            pred = result.claim_status
            predictions.append(pred)
            ground_truths.append(gt)
            rows.append({
                "claim_id": result.claim_id,
                "predicted_status": pred,
                "ground_truth_status": gt,
                "match": pred == gt,
                "confidence": result.confidence_score,
                "issue_type": result.issue_type,
                "object_part": result.object_part,
                "recommended_action": result.recommended_action,
                "reasoning": result.reasoning,
                "error": result.error,
            })

        metrics = compute_metrics(predictions, ground_truths)
        cm = compute_confusion_matrix(predictions, ground_truths)
        comparison_df = pd.DataFrame(rows)

        # Write report
        report = self._build_report(metrics, cm, comparison_df, results)
        with open(output_report_path, "w", encoding="utf-8") as f:
            f.write(report)

        logger.info(
            f"Evaluation complete. Accuracy={metrics['accuracy']:.2%}, "
            f"MacroF1={metrics['macro_f1']:.4f}. Report: {output_report_path}"
        )

        return {
            "metrics": metrics,
            "confusion_matrix": cm,
            "comparison_df": comparison_df,
            "results": results,
        }

    def _build_report(
        self,
        metrics: Dict,
        cm: Dict,
        comparison_df: pd.DataFrame,
        results: List[ClaimResult],
    ) -> str:
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        labels = ["supported", "contradicted", "not_enough_information"]

        lines = [
            "# Multi-Modal Evidence Review — Evaluation Report",
            f"\n**Generated:** {ts}",
            f"**Total Samples:** {metrics['n_samples']}",
            f"**Correct:** {metrics['n_correct']}",
            "",
            "---",
            "",
            "## Overall Metrics",
            "",
            f"| Metric | Score |",
            f"|--------|-------|",
            f"| Accuracy | {metrics['accuracy']:.2%} |",
            f"| Macro F1 | {metrics['macro_f1']:.4f} |",
            "",
            "---",
            "",
            "## Per-Class Metrics",
            "",
            "| Class | Precision | Recall | F1 | Support |",
            "|-------|-----------|--------|-----|---------|",
        ]
        for label in labels:
            m = metrics["per_class"].get(label, {})
            lines.append(
                f"| {label} | {m.get('precision', 0):.3f} | "
                f"{m.get('recall', 0):.3f} | {m.get('f1', 0):.3f} | {m.get('support', 0)} |"
            )

        lines += [
            "",
            "---",
            "",
            "## Confusion Matrix",
            "",
            "| True \\ Pred | " + " | ".join(labels) + " |",
            "|" + "---|" * (len(labels) + 1),
        ]
        for true_label in labels:
            row = f"| **{true_label}** | "
            row += " | ".join(str(cm.get(true_label, {}).get(pred_label, 0)) for pred_label in labels)
            row += " |"
            lines.append(row)

        lines += [
            "",
            "---",
            "",
            "## Per-Claim Results",
            "",
            "| Claim ID | Predicted | Ground Truth | Match | Confidence | Issue Type | Action |",
            "|----------|-----------|--------------|-------|-----------|-----------|--------|",
        ]
        for _, row in comparison_df.iterrows():
            match_icon = "✅" if row["match"] else "❌"
            lines.append(
                f"| {row['claim_id']} | {row['predicted_status']} | {row['ground_truth_status']} | "
                f"{match_icon} | {row['confidence']:.2f} | {row['issue_type']} | {row['recommended_action']} |"
            )

        # Error summary
        errors = comparison_df[comparison_df["error"] != ""]
        if not errors.empty:
            lines += [
                "",
                "---",
                "",
                "## Errors",
                "",
                f"**{len(errors)} claim(s) encountered errors:**",
                "",
            ]
            for _, row in errors.iterrows():
                lines.append(f"- `{row['claim_id']}`: {row['error']}")

        # Reasoning samples
        lines += [
            "",
            "---",
            "",
            "## Sample Reasoning (first 5 claims)",
            "",
        ]
        for _, row in comparison_df.head(5).iterrows():
            lines.append(f"**{row['claim_id']}** (`{row['predicted_status']}`): {row['reasoning']}")
            lines.append("")

        lines += [
            "---",
            "",
            "_Report generated by Multi-Modal Evidence Review Pipeline_",
        ]

        return "\n".join(lines)
