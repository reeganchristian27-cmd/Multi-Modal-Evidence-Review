"""
Data loading and preprocessing for the Evidence Review pipeline.
Handles claims, user history, and evidence requirements.
"""
import base64
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

from configs.config import Config, DEFAULT_CONFIG
from src.logger import logger


def load_claims(path: str) -> pd.DataFrame:
    """Load and validate the claims CSV."""
    df = pd.read_csv(path)
    required_cols = {"claim_id", "conversation", "image_paths"}
    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f"claims.csv missing columns: {missing}")
    df["image_paths"] = df["image_paths"].fillna("").astype(str)
    df["conversation"] = df["conversation"].fillna("").astype(str)
    logger.info(f"Loaded {len(df)} claims from {path}")
    return df


def load_sample_claims(path: str) -> pd.DataFrame:
    """Load labeled sample claims for evaluation."""
    df = pd.read_csv(path)
    required_cols = {"claim_id", "conversation", "image_paths", "claim_status"}
    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f"sample_claims.csv missing columns: {missing}")
    df["image_paths"] = df["image_paths"].fillna("").astype(str)
    logger.info(f"Loaded {len(df)} sample claims from {path}")
    return df


def load_user_history(path: str) -> Dict[str, Dict]:
    """Load user history and return as a dict keyed by user_id."""
    df = pd.read_csv(path)
    required_cols = {"user_id", "risk_score", "risk_level"}
    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f"user_history.csv missing columns: {missing}")
    history = {}
    for _, row in df.iterrows():
        uid = str(row["user_id"])
        history[uid] = row.to_dict()
    logger.info(f"Loaded history for {len(history)} users from {path}")
    return history


def load_evidence_requirements(path: str) -> Dict[str, Dict]:
    """Load evidence requirements keyed by issue_type."""
    df = pd.read_csv(path)
    requirements = {}
    for _, row in df.iterrows():
        issue = str(row["issue_type"]).strip().lower()
        requirements[issue] = row.to_dict()
    logger.info(f"Loaded {len(requirements)} evidence requirement rules from {path}")
    return requirements


def get_user_context(user_id: Optional[str], user_history: Dict[str, Dict]) -> Dict[str, Any]:
    """Return user risk context dict, using defaults for unknown users."""
    defaults = {
        "user_id": user_id or "unknown",
        "risk_score": 20,
        "risk_level": "low",
        "fraud_flags": 0,
        "total_claims": 0,
        "approved_claims": 0,
        "rejected_claims": 0,
        "rejection_rate": 0.0,
    }
    if not user_id or user_id not in user_history:
        logger.debug(f"No history for user {user_id}, using defaults")
        return defaults

    h = user_history[user_id]
    total = int(h.get("total_claims", 0))
    rejected = int(h.get("rejected_claims", 0))
    rejection_rate = rejected / total if total > 0 else 0.0

    return {
        "user_id": user_id,
        "risk_score": int(h.get("risk_score", 20)),
        "risk_level": str(h.get("risk_level", "low")),
        "fraud_flags": int(h.get("fraud_flags", 0)),
        "total_claims": total,
        "approved_claims": int(h.get("approved_claims", 0)),
        "rejected_claims": rejected,
        "rejection_rate": rejection_rate,
    }


def parse_image_paths(image_paths_str: str, images_dir: str = "images") -> List[str]:
    """Parse semicolon-separated image paths and resolve them."""
    if not image_paths_str or image_paths_str.strip() in ("", "nan"):
        return []
    paths = [p.strip() for p in image_paths_str.split(";") if p.strip()]
    resolved = []
    for p in paths:
        # Try as-is first, then relative to images_dir
        if os.path.exists(p):
            resolved.append(p)
        else:
            alt = os.path.join(images_dir, os.path.basename(p))
            if os.path.exists(alt):
                resolved.append(alt)
            else:
                logger.debug(f"Image not found: {p} (also tried {alt})")
                resolved.append(p)  # Keep path even if missing — model will skip
    return resolved


def encode_image_to_base64(image_path: str, max_bytes: int = 5_242_880) -> Optional[Tuple[str, str]]:
    """
    Read an image file and return (base64_data, media_type).
    Returns None if the file is missing, unreadable, or too large.
    """
    if not os.path.exists(image_path):
        logger.warning(f"Image not found: {image_path}")
        return None

    size = os.path.getsize(image_path)
    if size > max_bytes:
        logger.warning(f"Image too large ({size} bytes): {image_path}")
        return None

    ext = Path(image_path).suffix.lower()
    media_type_map = {
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".png": "image/png",
        ".gif": "image/gif",
        ".webp": "image/webp",
    }
    media_type = media_type_map.get(ext, "image/jpeg")

    try:
        with open(image_path, "rb") as f:
            data = f.read()
        b64 = base64.standard_b64encode(data).decode("utf-8")
        logger.debug(f"Encoded image {image_path} ({size} bytes) as {media_type}")
        return b64, media_type
    except Exception as e:
        logger.error(f"Failed to encode image {image_path}: {e}")
        return None


def get_evidence_context(issue_type: Optional[str], evidence_requirements: Dict[str, Dict]) -> str:
    """Return a human-readable evidence requirements string for the given issue type."""
    if not issue_type:
        return "No specific evidence requirements found. General physical damage rules apply."
    key = issue_type.strip().lower()
    if key not in evidence_requirements:
        # Try partial match
        for k in evidence_requirements:
            if k in key or key in k:
                key = k
                break
        else:
            return f"No specific rules for '{issue_type}'. Default: images required showing visible damage."

    req = evidence_requirements[key]
    lines = [
        f"Issue Type: {req.get('issue_type', key)}",
        f"Required Evidence: {req.get('required_evidence', 'image_of_damage')}",
        f"Minimum Images: {req.get('min_images', 1)}",
        f"Image Quality Required: {req.get('image_quality_requirements', 'clear_visible_damage')}",
        f"Accepted Object Parts: {req.get('accepted_object_parts', 'device_body')}",
        f"Description: {req.get('description', '')}",
    ]
    return "\n".join(lines)
