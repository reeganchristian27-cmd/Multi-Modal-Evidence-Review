"""
Disk-based cache for Anthropic API responses.
Keyed by a hash of the request payload to avoid re-calling the API for identical inputs.
"""
import hashlib
import json
import os
import time
from pathlib import Path
from typing import Any, Optional

from src.logger import logger


class ResponseCache:
    """Simple JSON file-based cache with TTL support."""

    def __init__(self, cache_dir: str = "cache", ttl_hours: int = 24):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.ttl_seconds = ttl_hours * 3600
        logger.debug(f"Cache initialized at {self.cache_dir}, TTL={ttl_hours}h")

    def _key_to_path(self, key: str) -> Path:
        return self.cache_dir / f"{key}.json"

    def _make_key(self, payload: dict) -> str:
        """Stable hash of a dict, ignoring key order."""
        serialized = json.dumps(payload, sort_keys=True, ensure_ascii=False)
        return hashlib.sha256(serialized.encode()).hexdigest()[:16]

    def get(self, payload: dict) -> Optional[Any]:
        key = self._make_key(payload)
        path = self._key_to_path(key)
        if not path.exists():
            return None
        try:
            with open(path, "r", encoding="utf-8") as f:
                entry = json.load(f)
            age = time.time() - entry["timestamp"]
            if age > self.ttl_seconds:
                path.unlink(missing_ok=True)
                logger.debug(f"Cache entry expired: {key}")
                return None
            logger.debug(f"Cache hit: {key}")
            return entry["value"]
        except Exception as e:
            logger.warning(f"Cache read error for {key}: {e}")
            return None

    def set(self, payload: dict, value: Any) -> None:
        key = self._make_key(payload)
        path = self._key_to_path(key)
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump({"timestamp": time.time(), "value": value}, f, ensure_ascii=False)
            logger.debug(f"Cache set: {key}")
        except Exception as e:
            logger.warning(f"Cache write error for {key}: {e}")

    def clear(self) -> int:
        """Remove all cache files. Returns count deleted."""
        count = 0
        for p in self.cache_dir.glob("*.json"):
            p.unlink()
            count += 1
        logger.info(f"Cache cleared: {count} entries removed")
        return count
