"""
Anthropic API client wrapper with retry, caching, and multimodal support.
"""
import json
import re
import time
from typing import Any, Dict, List, Optional

import anthropic

from src.cache import ResponseCache
from configs.config import Config, DEFAULT_CONFIG
from src.logger import logger


class AnthropicClient:
    """
    Wraps the Anthropic SDK with:
    - Retry with exponential backoff
    - Request/response caching
    - JSON extraction from responses
    - Multimodal (text + image) message construction
    """

    def __init__(self, config: Config = DEFAULT_CONFIG):
        self.config = config
        api_key = config.anthropic_api_key
        if not api_key:
            raise ValueError(
                "ANTHROPIC_API_KEY environment variable not set. "
                "Export it before running: export ANTHROPIC_API_KEY=your_key"
            )
        self.client = anthropic.Anthropic(api_key=api_key)
        self.cache = ResponseCache(
            cache_dir=config.cache_dir,
            ttl_hours=config.cache_ttl_hours,
        ) if config.enable_cache else None
        logger.info(f"AnthropicClient initialized. Model: {config.model}")

    # ─── Message construction ────────────────────────────────────────────────

    def build_multimodal_message(
        self,
        text: str,
        images: List[Dict[str, str]],  # [{"data": b64, "media_type": "image/jpeg"}, ...]
    ) -> List[Dict]:
        """Build a user message with text and optional base64 images."""
        content: List[Dict] = []
        for img in images:
            content.append({
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": img["media_type"],
                    "data": img["data"],
                },
            })
        content.append({"type": "text", "text": text})
        return [{"role": "user", "content": content}]

    # ─── Core call ───────────────────────────────────────────────────────────

    def call(
        self,
        system_prompt: str,
        user_prompt: str,
        images: Optional[List[Dict[str, str]]] = None,
        cache_key_extra: Optional[str] = None,
    ) -> Optional[str]:
        """
        Send a request to the Anthropic API.
        Returns the text response, or None on failure.
        """
        images = images or []

        # Build cache payload (images too large to cache by content — use path-based key)
        cache_payload = {
            "model": self.config.model,
            "system": system_prompt,
            "user": user_prompt,
            "n_images": len(images),
            "extra": cache_key_extra or "",
        }

        if self.cache:
            cached = self.cache.get(cache_payload)
            if cached is not None:
                logger.debug("Returning cached API response")
                return cached

        messages = self.build_multimodal_message(user_prompt, images)

        for attempt in range(1, self.config.max_retries + 1):
            try:
                response = self.client.messages.create(
                    model=self.config.model,
                    max_tokens=self.config.max_tokens,
                    temperature=self.config.temperature,
                    system=system_prompt,
                    messages=messages,
                )
                text = response.content[0].text
                logger.debug(f"API call succeeded on attempt {attempt}")

                if self.cache:
                    self.cache.set(cache_payload, text)

                return text

            except anthropic.RateLimitError as e:
                wait = self.config.retry_delay_seconds * (2 ** attempt)
                logger.warning(f"Rate limit hit (attempt {attempt}/{self.config.max_retries}). Waiting {wait}s. {e}")
                time.sleep(wait)
            except anthropic.APIStatusError as e:
                logger.error(f"API error on attempt {attempt}: {e.status_code} — {e.message}")
                if attempt == self.config.max_retries:
                    return None
                time.sleep(self.config.retry_delay_seconds * attempt)
            except Exception as e:
                logger.error(f"Unexpected error on attempt {attempt}: {e}")
                if attempt == self.config.max_retries:
                    return None
                time.sleep(self.config.retry_delay_seconds)

        return None

    # ─── JSON extraction ─────────────────────────────────────────────────────

    def extract_json(self, text: str) -> Optional[Dict[str, Any]]:
        """
        Extract JSON from a model response.
        Handles: raw JSON, fenced ```json blocks, and JSON embedded in prose.
        """
        if not text:
            return None

        # Remove markdown fences
        cleaned = re.sub(r"```(?:json)?\s*", "", text).strip().rstrip("`").strip()

        # Try direct parse
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            pass

        # Find JSON object via regex
        match = re.search(r"\{[\s\S]*\}", cleaned)
        if match:
            try:
                return json.loads(match.group())
            except json.JSONDecodeError:
                pass

        logger.warning(f"Could not extract JSON from response: {text[:200]}")
        return None
