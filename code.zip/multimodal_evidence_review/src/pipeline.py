"""
Core claim analysis pipeline.
Orchestrates data loading, image encoding, API calls, and result assembly.
"""
import json
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional

import pandas as pd

from prompts.templates import (
    SYSTEM_PROMPT_CLAIM_ANALYSIS,
    USER_PROMPT_CLAIM_ANALYSIS,
    USER_PROMPT_NO_IMAGES,
)
from src.api_client import AnthropicClient
from configs.config import Config, DEFAULT_CONFIG
from src.data_loader import (
    encode_image_to_base64,
    get_evidence_context,
    get_user_context,
    parse_image_paths,
)
from src.logger import logger


# ─── Result dataclass ─────────────────────────────────────────────────────────

@dataclass
class ClaimResult:
    claim_id: str
    user_id: str = ""
    issue_type: str = "unknown"
    object_part: str = "unknown"
    claim_status: str = "not_enough_information"
    confidence_score: float = 0.0
    image_quality: str = "no_image"
    evidence_sufficient: bool = False
    damage_visible_in_image: Optional[bool] = None
    damage_consistent_with_claim: Optional[bool] = None
    risk_flags: List[str] = field(default_factory=list)
    reasoning: str = ""
    recommended_action: str = "request_more_evidence"
    error: str = ""
    n_images_submitted: int = 0
    user_risk_level: str = "low"
    user_risk_score: int = 0

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["risk_flags"] = ";".join(d["risk_flags"]) if d["risk_flags"] else ""
        return d


# ─── Pipeline ─────────────────────────────────────────────────────────────────

class EvidenceReviewPipeline:
    """
    End-to-end pipeline for multimodal claim analysis.
    """

    VALID_STATUSES = {"supported", "contradicted", "not_enough_information"}
    VALID_ACTIONS = {"approve", "reject", "escalate_for_review", "request_more_evidence"}

    def __init__(
        self,
        user_history: Dict[str, Dict],
        evidence_requirements: Dict[str, Dict],
        api_client: Optional[AnthropicClient] = None,
        config: Config = DEFAULT_CONFIG,
    ):
        self.user_history = user_history
        self.evidence_requirements = evidence_requirements
        self.config = config
        self.client = api_client or AnthropicClient(config)
        logger.info("EvidenceReviewPipeline initialized")

    # ─── Image loading ────────────────────────────────────────────────────────

    def _load_images(self, image_paths: List[str]) -> List[Dict[str, str]]:
        """Load and encode images for API submission."""
        encoded = []
        for path in image_paths[: self.config.max_images_per_claim]:
            result = encode_image_to_base64(path, self.config.image_max_size_bytes)
            if result:
                b64, media_type = result
                encoded.append({"data": b64, "media_type": media_type})
            else:
                logger.warning(f"Skipping unloadable image: {path}")
        return encoded

    # ─── Pre-detection of issue type ─────────────────────────────────────────

    def _detect_issue_type_heuristic(self, conversation: str) -> Optional[str]:
        """
        Quick keyword heuristic to pre-select evidence requirements before
        calling the API. The API will confirm or override this.
        """
        text = conversation.lower()
        if any(w in text for w in ["screen", "crack", "display", "dead pixel"]):
            return "screen_damage"
        if any(w in text for w in ["water", "wet", "liquid", "spill", "flood", "rain", "pool"]):
            return "water_damage"
        if any(w in text for w in ["fire", "burn", "burnt", "flame", "smoke"]):
            return "fire_damage"
        if any(w in text for w in ["stolen", "theft", "steal", "missing", "took"]):
            return "theft"
        if any(w in text for w in ["scratch", "scratched"]):
            return "scratch_damage"
        if any(w in text for w in ["charg", "port", "usb", "connector"]):
            return "charging_damage"
        if any(w in text for w in ["hinge", "snap", "broke", "crack", "broken", "smash", "crush", "fell"]):
            return "physical_damage"
        return "physical_damage"  # default

    # ─── Single claim analysis ────────────────────────────────────────────────

    def analyze_claim(
        self,
        claim_id: str,
        conversation: str,
        image_paths_str: str,
        user_id: Optional[str] = None,
    ) -> ClaimResult:
        """Analyze a single claim and return a ClaimResult."""
        logger.info(f"Analyzing claim {claim_id} (user={user_id})")

        # User context
        user_ctx = get_user_context(user_id, self.user_history)

        # Parse & load images
        paths = parse_image_paths(image_paths_str, self.config.images_dir)
        images = self._load_images(paths) if paths else []
        n_images = len(images)

        # Evidence requirements (pre-detection)
        issue_hint = self._detect_issue_type_heuristic(conversation)
        evidence_ctx = get_evidence_context(issue_hint, self.evidence_requirements)

        # Build prompt
        if n_images == 0:
            prompt = USER_PROMPT_NO_IMAGES.format(
                claim_id=claim_id,
                user_risk_level=user_ctx["risk_level"],
                user_risk_score=user_ctx["risk_score"],
                fraud_flags=user_ctx["fraud_flags"],
                conversation=conversation,
                evidence_requirements=evidence_ctx,
            )
        else:
            image_instruction = (
                f"{n_images} image(s) are provided. "
                "Carefully examine each image for visible damage evidence."
            )
            prompt = USER_PROMPT_CLAIM_ANALYSIS.format(
                claim_id=claim_id,
                user_risk_level=user_ctx["risk_level"],
                user_risk_score=user_ctx["risk_score"],
                fraud_flags=user_ctx["fraud_flags"],
                total_claims=user_ctx["total_claims"],
                rejection_rate=user_ctx["rejection_rate"],
                conversation=conversation,
                evidence_requirements=evidence_ctx,
                image_instruction=image_instruction,
            )

        # API call
        cache_key = f"{claim_id}_{n_images}_{user_ctx['risk_level']}"
        raw_response = self.client.call(
            system_prompt=SYSTEM_PROMPT_CLAIM_ANALYSIS,
            user_prompt=prompt,
            images=images,
            cache_key_extra=cache_key,
        )

        if not raw_response:
            logger.error(f"No response from API for claim {claim_id}")
            return ClaimResult(
                claim_id=claim_id,
                user_id=user_id or "",
                error="API call failed",
                user_risk_level=user_ctx["risk_level"],
                user_risk_score=user_ctx["risk_score"],
                n_images_submitted=n_images,
            )

        # Parse JSON
        parsed = self.client.extract_json(raw_response)
        if not parsed:
            logger.error(f"Could not parse JSON for claim {claim_id}: {raw_response[:300]}")
            return ClaimResult(
                claim_id=claim_id,
                user_id=user_id or "",
                error=f"JSON parse failure: {raw_response[:100]}",
                user_risk_level=user_ctx["risk_level"],
                user_risk_score=user_ctx["risk_score"],
                n_images_submitted=n_images,
            )

        # Apply high-risk escalation override
        risk_flags = list(parsed.get("risk_flags", []))
        claim_status = parsed.get("claim_status", "not_enough_information")
        recommended_action = parsed.get("recommended_action", "request_more_evidence")

        if (
            user_ctx["risk_score"] >= self.config.high_risk_score_threshold
            and claim_status == "supported"
            and user_ctx["fraud_flags"] >= self.config.fraud_flag_escalation_threshold
        ):
            recommended_action = "escalate_for_review"
            risk_flags.append("high_risk_user_escalated")
            logger.info(f"Claim {claim_id} escalated due to high-risk user profile")

        # Validate enum values
        if claim_status not in self.VALID_STATUSES:
            logger.warning(f"Invalid claim_status '{claim_status}' for {claim_id}, defaulting")
            claim_status = "not_enough_information"
        if recommended_action not in self.VALID_ACTIONS:
            recommended_action = "request_more_evidence"

        return ClaimResult(
            claim_id=claim_id,
            user_id=user_id or "",
            issue_type=parsed.get("issue_type", issue_hint or "unknown"),
            object_part=parsed.get("object_part", "unknown"),
            claim_status=claim_status,
            confidence_score=float(parsed.get("confidence_score", 0.0)),
            image_quality=parsed.get("image_quality", "no_image"),
            evidence_sufficient=bool(parsed.get("evidence_sufficient", False)),
            damage_visible_in_image=parsed.get("damage_visible_in_image"),
            damage_consistent_with_claim=parsed.get("damage_consistent_with_claim"),
            risk_flags=risk_flags,
            reasoning=parsed.get("reasoning", ""),
            recommended_action=recommended_action,
            n_images_submitted=n_images,
            user_risk_level=user_ctx["risk_level"],
            user_risk_score=user_ctx["risk_score"],
        )

    # ─── Batch processing ─────────────────────────────────────────────────────

    def process_batch(self, claims_df: pd.DataFrame) -> List[ClaimResult]:
        """Process a DataFrame of claims in batches and return results."""
        results = []
        total = len(claims_df)

        for i, (_, row) in enumerate(claims_df.iterrows()):
            claim_id = str(row.get("claim_id", f"CLAIM_{i}"))
            user_id = str(row.get("user_id", "")) if "user_id" in row and pd.notna(row.get("user_id")) else None
            conversation = str(row.get("conversation", ""))
            image_paths = str(row.get("image_paths", ""))

            logger.info(f"Processing claim {i+1}/{total}: {claim_id}")
            try:
                result = self.analyze_claim(claim_id, conversation, image_paths, user_id)
            except Exception as e:
                logger.error(f"Unhandled error for claim {claim_id}: {e}", exc_info=True)
                result = ClaimResult(
                    claim_id=claim_id,
                    user_id=user_id or "",
                    error=str(e),
                )
            results.append(result)

        logger.info(f"Batch complete: {len(results)} claims processed")
        return results

    # ─── Output generation ────────────────────────────────────────────────────

    @staticmethod
    def results_to_dataframe(results: List[ClaimResult]) -> pd.DataFrame:
        return pd.DataFrame([r.to_dict() for r in results])

    @staticmethod
    def save_output(results: List[ClaimResult], output_path: str) -> None:
        import os
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        df = EvidenceReviewPipeline.results_to_dataframe(results)
        df.to_csv(output_path, index=False)
        logger.info(f"Output saved to {output_path} ({len(results)} rows)")
