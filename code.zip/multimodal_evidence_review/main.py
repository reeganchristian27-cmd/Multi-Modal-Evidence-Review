"""
Main entry point for the Multi-Modal Evidence Review pipeline.

Usage:
    python main.py                          # Run full pipeline on claims.csv
    python main.py --evaluate               # Run evaluation on sample_claims.csv first
    python main.py --evaluate --only-eval   # Evaluation only, no production run
    python main.py --claims path/to/claims.csv
    python main.py --clear-cache            # Clear response cache
"""
import argparse
import os
import sys
from pathlib import Path

import pandas as pd

from src.api_client import AnthropicClient
from configs.config import Config, DEFAULT_CONFIG
from src.data_loader import (
    load_claims,
    load_evidence_requirements,
    load_sample_claims,
    load_user_history,
)
from src.evaluator import PipelineEvaluator
from src.logger import logger, setup_logger
from src.pipeline import EvidenceReviewPipeline


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Multi-Modal Evidence Review Pipeline"
    )
    parser.add_argument(
        "--claims",
        default=DEFAULT_CONFIG.claims_file,
        help="Path to claims CSV (default: data/claims.csv)",
    )
    parser.add_argument(
        "--sample-claims",
        default=DEFAULT_CONFIG.sample_claims_file,
        help="Path to labeled sample claims CSV for evaluation",
    )
    parser.add_argument(
        "--user-history",
        default=DEFAULT_CONFIG.user_history_file,
        help="Path to user history CSV",
    )
    parser.add_argument(
        "--evidence-requirements",
        default=DEFAULT_CONFIG.evidence_requirements_file,
        help="Path to evidence requirements CSV",
    )
    parser.add_argument(
        "--output",
        default=DEFAULT_CONFIG.output_file,
        help="Path for output CSV (default: output/output.csv)",
    )
    parser.add_argument(
        "--evaluate",
        action="store_true",
        help="Run evaluation on sample_claims.csv before production run",
    )
    parser.add_argument(
        "--only-eval",
        action="store_true",
        help="Only run evaluation, skip production claims",
    )
    parser.add_argument(
        "--clear-cache",
        action="store_true",
        help="Clear the response cache before running",
    )
    parser.add_argument(
        "--model",
        default=DEFAULT_CONFIG.model,
        help=f"Anthropic model to use (default: {DEFAULT_CONFIG.model})",
    )
    parser.add_argument(
        "--no-cache",
        action="store_true",
        help="Disable response caching",
    )
    return parser.parse_args()


def build_config(args: argparse.Namespace) -> Config:
    cfg = Config()
    cfg.model = args.model
    if args.no_cache:
        cfg.enable_cache = False
    return cfg


def main() -> int:
    args = parse_args()
    config = build_config(args)

    # Validate API key
    if not os.environ.get("ANTHROPIC_API_KEY"):
        logger.error("ANTHROPIC_API_KEY is not set. Export it before running.")
        print("\nERROR: ANTHROPIC_API_KEY environment variable is required.")
        print("  export ANTHROPIC_API_KEY=sk-ant-...")
        return 1

    # Initialize components
    try:
        api_client = AnthropicClient(config)
    except ValueError as e:
        logger.error(str(e))
        return 1

    if args.clear_cache and config.enable_cache:
        from src.cache import ResponseCache
        cache = ResponseCache(config.cache_dir)
        n = cache.clear()
        logger.info(f"Cleared {n} cached responses")

    # Load supporting data
    logger.info("Loading supporting data...")
    user_history = load_user_history(args.user_history)
    evidence_requirements = load_evidence_requirements(args.evidence_requirements)

    # Build pipeline
    pipeline = EvidenceReviewPipeline(
        user_history=user_history,
        evidence_requirements=evidence_requirements,
        api_client=api_client,
        config=config,
    )

    # ── EVALUATION ────────────────────────────────────────────────────────────
    if args.evaluate or args.only_eval:
        logger.info(f"Loading sample claims from {args.sample_claims}")
        try:
            sample_df = load_sample_claims(args.sample_claims)
        except Exception as e:
            logger.error(f"Failed to load sample claims: {e}")
            return 1

        evaluator = PipelineEvaluator(pipeline)
        eval_results = evaluator.evaluate(
            sample_df,
            output_report_path=config.evaluation_output_file,
        )

        metrics = eval_results["metrics"]
        print(f"\n{'='*60}")
        print("EVALUATION RESULTS")
        print(f"{'='*60}")
        print(f"  Accuracy:  {metrics['accuracy']:.2%}")
        print(f"  Macro F1:  {metrics['macro_f1']:.4f}")
        print(f"  Samples:   {metrics['n_samples']}")
        print(f"  Correct:   {metrics['n_correct']}")
        print(f"\n  Per-class F1:")
        for label, m in metrics["per_class"].items():
            print(f"    {label:<30} F1={m['f1']:.3f}  P={m['precision']:.3f}  R={m['recall']:.3f}")
        print(f"\n  Report: {config.evaluation_output_file}")
        print(f"{'='*60}\n")

    if args.only_eval:
        logger.info("--only-eval set: skipping production run")
        return 0

    # ── PRODUCTION RUN ────────────────────────────────────────────────────────
    logger.info(f"Loading production claims from {args.claims}")
    try:
        claims_df = load_claims(args.claims)
    except Exception as e:
        logger.error(f"Failed to load claims: {e}")
        return 1

    logger.info(f"Processing {len(claims_df)} claims...")
    results = pipeline.process_batch(claims_df)

    # Save output
    EvidenceReviewPipeline.save_output(results, args.output)

    # Print summary
    status_counts = {}
    for r in results:
        status_counts[r.claim_status] = status_counts.get(r.claim_status, 0) + 1

    print(f"\n{'='*60}")
    print("PRODUCTION RUN COMPLETE")
    print(f"{'='*60}")
    print(f"  Total claims processed: {len(results)}")
    for status, count in sorted(status_counts.items()):
        print(f"  {status:<35} {count}")
    print(f"\n  Output: {args.output}")
    print(f"{'='*60}\n")

    return 0


if __name__ == "__main__":
    sys.exit(main())
