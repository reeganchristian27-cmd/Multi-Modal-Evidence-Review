"""
Prompt templates for the Multi-Modal Evidence Review pipeline.
"""

SYSTEM_PROMPT_CLAIM_ANALYSIS = """You are an expert insurance claim adjuster specializing in electronic device damage assessment.
Your role is to analyze damage claims by examining:
1. Conversation text between the claimant and support agent
2. Submitted photographic evidence (images)
3. Evidence requirements for the claimed damage type
4. User risk history context

You must make objective, evidence-based determinations. Images are the PRIMARY source of truth.
User history context may raise scrutiny level but NEVER overrides clear visual evidence.

You output structured JSON only. No prose outside the JSON object.
"""

USER_PROMPT_CLAIM_ANALYSIS = """Analyze the following insurance claim and provide a structured assessment.

=== CLAIM INFORMATION ===
Claim ID: {claim_id}
User Risk Level: {user_risk_level}
User Risk Score: {user_risk_score}
Prior Fraud Flags: {fraud_flags}
Total Prior Claims: {total_claims}
Prior Rejection Rate: {rejection_rate:.1%}

=== CONVERSATION ===
{conversation}

=== EVIDENCE REQUIREMENTS ===
{evidence_requirements}

=== TASK ===
Analyze the conversation to extract the damage claim details.
{image_instruction}

Respond with ONLY a valid JSON object in this exact format:
{{
  "claim_id": "{claim_id}",
  "issue_type": "<detected issue type, e.g. screen_damage, water_damage, physical_damage, fire_damage, charging_damage, scratch_damage, theft, internal_damage>",
  "object_part": "<specific part claimed damaged, e.g. display, keyboard, charging_port, hinge, ear_cup, lens, device_body>",
  "claim_status": "<one of: supported, contradicted, not_enough_information>",
  "confidence_score": <float 0.0-1.0>,
  "image_quality": "<one of: clear, blurry, no_image, insufficient_detail, adequate>",
  "evidence_sufficient": <true or false>,
  "damage_visible_in_image": <true, false, or null if no image>,
  "damage_consistent_with_claim": <true, false, or null if no image>,
  "risk_flags": ["<list any risk flags identified>"],
  "reasoning": "<brief 1-2 sentence explanation of the determination>",
  "recommended_action": "<one of: approve, reject, escalate_for_review, request_more_evidence>"
}}

Rules:
- claim_status=supported: images clearly show the claimed damage AND it matches the conversation
- claim_status=contradicted: images actively contradict the claim (e.g., no damage visible, wrong damage type)
- claim_status=not_enough_information: no images, blurry images, internal damage not visible, or insufficient evidence
- High-risk users get closer scrutiny but visual evidence still determines the outcome
- Theft claims without images can only be "not_enough_information" unless a police report is mentioned
"""

USER_PROMPT_NO_IMAGES = """Analyze the following insurance claim (NO IMAGES PROVIDED).

=== CLAIM INFORMATION ===
Claim ID: {claim_id}
User Risk Level: {user_risk_level}
User Risk Score: {user_risk_score}
Prior Fraud Flags: {fraud_flags}

=== CONVERSATION ===
{conversation}

=== EVIDENCE REQUIREMENTS ===
{evidence_requirements}

No images were submitted with this claim. Analyze based on conversation only.

Respond with ONLY a valid JSON object:
{{
  "claim_id": "{claim_id}",
  "issue_type": "<detected issue type>",
  "object_part": "<specific part claimed damaged>",
  "claim_status": "not_enough_information",
  "confidence_score": <float 0.0-1.0>,
  "image_quality": "no_image",
  "evidence_sufficient": false,
  "damage_visible_in_image": null,
  "damage_consistent_with_claim": null,
  "risk_flags": ["no_images_submitted"],
  "reasoning": "<brief explanation>",
  "recommended_action": "request_more_evidence"
}}
"""

EVALUATION_PROMPT = """Compare two claim status labels and determine if they match.

Predicted: {predicted}
Ground Truth: {ground_truth}

Consider these equivalences:
- Exact match = 1.0
- "not_enough_information" vs any other = partial credit 0.5 if the logic is sound
- "supported" vs "contradicted" = 0.0 (complete mismatch)

Return JSON: {{"match": true/false, "partial": true/false, "score": 0.0-1.0}}
"""
